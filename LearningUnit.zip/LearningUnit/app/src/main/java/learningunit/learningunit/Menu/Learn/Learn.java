package learningunit.learningunit.Menu.Learn;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import learningunit.learningunit.Menu.Learn.Vocabulary.Vokabeln;
import learningunit.learningunit.Menu.MainActivity;
import learningunit.learningunit.R;

public class Learn extends AppCompatActivity {

    //Deklarieren der Knöpfe
    private Button back, vocabulary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learn);


        //Initialisieren der Knöpfe und rufen der OnClick methode
        back = (Button) findViewById(R.id.learn_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_back();
            }
        });

        vocabulary = (Button) findViewById(R.id.learn_vocabulary);
        vocabulary.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_vocabulary();
            }
        });

    }



    //Buttton OnClick Methoden
    public void open_back(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void open_vocabulary(){
        Intent intent = new Intent(this, Vokabeln.class);
        startActivity(intent);
    }


}
