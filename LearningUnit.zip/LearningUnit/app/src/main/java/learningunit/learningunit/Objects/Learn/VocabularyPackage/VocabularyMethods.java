package learningunit.learningunit.Objects.Learn.VocabularyPackage;


import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import learningunit.learningunit.Menu.MainActivity;

public class VocabularyMethods {

    public static List<VocabularyList> vocabularylists;

    public static boolean nameavailable(String name){
        boolean a = true;
        CharSequence search = "AllVoc_";
        if(name.contains(search) == false) {
            if (vocabularylists != null) {
                for (int i = 0; i < vocabularylists.size(); i++) {
                    VocabularyList list = vocabularylists.get(i);
                    if (list.getName().equalsIgnoreCase(name)) {
                        a = false;
                    }
                }
            }
        }else{
            a = false;
        }
        return a;
    }

    public static int VocabularyLanguageUsed(String language1, String language2){
        //If int Not Used = 0 --> Used; if 1 --> Used; if 2 --> Used but swapped languages
        int Used = 0;

        if (vocabularylists != null) {
            for (int i = 0; i < vocabularylists.size(); i++) {
                VocabularyList list = vocabularylists.get(i);
                if (list.getName().equalsIgnoreCase("AllVoc_" + language1 + "_" + language2)) {
                    Used = 1;
                    Log.d("Vocabulary", "Used ( AllVoc_" + language1 + "_" + language2 + " ) "  + 1);
                    return 1;

                }else if (list.getName().equalsIgnoreCase("AllVoc_" + language2 + "_" + language1)) {
                    //Used = 2;
                    Log.d("Vocabulary", "Used ( AllVoc_" + language1 + "_" + language2 + " ) "  + 2);
                    return  2;

                }
            }
        }
        return 0;
    }

    public static void loadVocabularyLists(){
        Gson gson = new Gson();
        String json = MainActivity.tinyDB.getString("VocLists");
        if(json != null){
            Type type = new TypeToken<ArrayList<VocabularyList>>() {}.getType();
            VocabularyMethods.vocabularylists = gson.fromJson(json, type);
        }else{
            VocabularyMethods.vocabularylists = new ArrayList<VocabularyList>();
        }
    }

    public static VocabularyList getVocabularyList(String name){
        for (int i = 0; i < vocabularylists.size(); i ++){
            VocabularyList list = vocabularylists.get(i);
            if(list.getName().equalsIgnoreCase(name)){
                Log.d("getVocabularyList", "return");
                return vocabularylists.get(i);
            }
        }
        Log.d("getVocabularyList", "Null");
        return null;
    }



    public static void removeVocabularyList(VocabularyList list){
        vocabularylists.remove(list);
    }

    public static void saveVocabularyList(VocabularyList VocList){

        if(VocabularyMethods.vocabularylists != null) {
            if (!(VocabularyMethods.vocabularylists.contains(VocList))) {
                VocabularyMethods.vocabularylists.add(VocList);
            }else{
                int index = vocabularylists.indexOf(VocList);
                Log.d("List", "Id: " + index + " Size: " + vocabularylists.size() + " vocabularylists: " + vocabularylists);
                VocabularyMethods.vocabularylists.remove(index);
                if(vocabularylists.size() == 0) {
                    Log.d("List1", "Id: " + index + " Size: " + vocabularylists.size() + " vocabularylists: " + vocabularylists);
                    VocabularyMethods.vocabularylists.add(VocList);
                    Log.d("List2", "Id: " + index + " Size: " + vocabularylists.size() + " vocabularylists: " + vocabularylists);
                }else{
                    Log.d("List1", "Id: " + index + " Size: " + vocabularylists.size() + " vocabularylists: " + vocabularylists);
                    VocabularyMethods.vocabularylists.add(VocList);
                    Log.d("List2", "Id: " + index + " Size: " + vocabularylists.size() + " vocabularylists: " + vocabularylists);
                }
            }
        }else{
            VocabularyMethods.vocabularylists = new ArrayList<VocabularyList>();
            VocabularyMethods.vocabularylists.add(VocList);
        }

    }


}
