package learningunit.learningunit.BeforeStart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import learningunit.learningunit.Menu.MainActivity;
import learningunit.learningunit.R;

public class Login extends AppCompatActivity {

    //Deklarieren der Knöpfe
    private Button login, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Initialisieren der Knöpfe und rufen der OnClick methode
        login = (Button) findViewById(R.id.login_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_login();
            }
        });

        back = (Button) findViewById(R.id.login_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_back();
            }
        });

    }

    //Buttton OnClick Methoden
    public void open_login(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void open_back(){
        Intent intent = new Intent(this, FirstScreen.class);
        startActivity(intent);
    }
}
