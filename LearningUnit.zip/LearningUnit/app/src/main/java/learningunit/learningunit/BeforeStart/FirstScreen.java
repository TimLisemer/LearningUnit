package learningunit.learningunit.BeforeStart;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import learningunit.learningunit.Menu.MainActivity;
import learningunit.learningunit.R;

public class FirstScreen extends AppCompatActivity {

    //Deklarieren der Knöpfe
    private Button continue1, continue2, login, register, back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_screen);

        //Initialisieren der Knöpfe und rufen der OnClick methode
        continue1 = (Button) findViewById(R.id.first_continue);
        continue1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_continue1();
            }
        });

        continue2 = (Button) findViewById(R.id.first_continue1);
        continue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_continue2();
            }
        });

        login = (Button) findViewById(R.id.first_login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_login();
            }
        });

        register = (Button) findViewById(R.id.first_register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_register();
            }
        });

        back = (Button) findViewById(R.id.first_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_back();
            }
        });

    }


    //Buttton OnClick Methoden
    public void open_continue1(){
        findViewById(R.id.first_scrollview).setVisibility(View.INVISIBLE);
        findViewById(R.id.first_scrollview1).setVisibility(View.VISIBLE);
    }

    public void open_continue2(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void open_login(){
        Intent intent = new Intent(this, Login.class);
        startActivity(intent);
    }

    public void open_register(){
        Intent intent = new Intent(this, Register.class);
        startActivity(intent);
    }

    public void open_back(){
        findViewById(R.id.first_scrollview).setVisibility(View.VISIBLE);
        findViewById(R.id.first_scrollview1).setVisibility(View.INVISIBLE);
    }




}
