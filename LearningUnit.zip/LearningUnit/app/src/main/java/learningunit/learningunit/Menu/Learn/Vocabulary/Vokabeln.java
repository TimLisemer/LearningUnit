package learningunit.learningunit.Menu.Learn.Vocabulary;

import android.content.Intent;
import android.support.constraint.ConstraintLayout;
import android.support.constraint.ConstraintSet;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Random;

import learningunit.learningunit.Menu.Learn.Learn;
import learningunit.learningunit.Menu.MainActivity;
import learningunit.learningunit.Objects.Learn.VocabularyPackage.Vocabulary;
import learningunit.learningunit.Objects.Learn.VocabularyPackage.VocabularyList;
import learningunit.learningunit.Objects.Learn.VocabularyPackage.VocabularyMethods;
import learningunit.learningunit.R;


public class Vokabeln extends AppCompatActivity {

    private Button back, back1, create, base, train, all;
    private TextView lang1, lang2, original, translation, error, nolist;
    ConstraintLayout layout, layout1;
    ConstraintSet constraintSet, constraintSeto, constraintSett;

    private ArrayList<Vocabulary> vocabularylist;
    private ArrayList<Button> buttonlist = new ArrayList<Button>();
    private ArrayList<Button> buttonlanglist = new ArrayList<Button>();
    private TextView downoriginal[];
    private TextView downtranslation[];

    //Lernbereich

    private Button learn_back, learn_enter, learn_showtranslation, learn_right, learn_wrong;

    private TextView learn_level0, learn_level1, learn_level2, learn_level3, learn_level4,
            learn_level0Score, learn_level1Score, learn_level2Score, learn_level3Score, learn_level4Score,
            learn_language, learn_original, learn_language1, learn_languages, learn_vocabularys, learn_masterTranslation;

    private EditText learn_translation;

    private TextInputLayout learn_input;

    //Lernbereich


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary);

        //Lernbereich

        learn_back = (Button) findViewById(R.id.vocabulary_learn_back);
        learn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_learn_back();
            }
        });

        learn_enter = (Button) findViewById(R.id.vocabulary_learn_enter);

        learn_showtranslation = (Button) findViewById(R.id.vocabulary_learn_showTranslation);
        learn_right = (Button) findViewById(R.id.vocabulary_learn_right);
        learn_wrong = (Button) findViewById(R.id.vocabulary_learn_wrong);



        learn_level0 = (TextView) findViewById(R.id.vocabulary_learn_level0);
        learn_level1 = (TextView) findViewById(R.id.vocabulary_learn_level1);
        learn_level2 = (TextView) findViewById(R.id.vocabulary_learn_level2);
        learn_level3 = (TextView) findViewById(R.id.vocabulary_learn_level3);
        learn_level4 = (TextView) findViewById(R.id.vocabulary_learn_level4);


        learn_level0Score = (TextView) findViewById(R.id.vocabulary_learn_level0count);
        learn_level1Score = (TextView) findViewById(R.id.vocabulary_learn_level1count);
        learn_level2Score = (TextView) findViewById(R.id.vocabulary_learn_level2count);
        learn_level3Score = (TextView) findViewById(R.id.vocabulary_learn_level3count);
        learn_level4Score = (TextView) findViewById(R.id.vocabulary_learn_level4count);

        learn_language = (TextView) findViewById(R.id.vocabulary_learn_language);
        learn_original = (TextView) findViewById(R.id.vocabulary_learn_original);
        learn_language1 = (TextView) findViewById(R.id.vocabulary_learn_language1);
        learn_languages = (TextView) findViewById(R.id.vocabulary_learn_languages);
        learn_vocabularys = (TextView) findViewById(R.id.vocabulary_learn_vocabularys);

        learn_masterTranslation = (TextView) findViewById(R.id.vocabulary_learn_masterTranslation);

        learn_input = (TextInputLayout) findViewById(R.id.vocabulary_learn_inputlayout);
        learn_translation = (EditText) findViewById(R.id.vocabulary_learn_editText);

        learn_translation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String inhalt = learn_translation.getText().toString().trim();
                learn_enter.setEnabled(!inhalt.isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        //Lernbereich


        layout = (ConstraintLayout) findViewById(R.id.vocabulary_scrollview4);
        layout1 = (ConstraintLayout) findViewById(R.id.vocabulary_constraintlayout1);
        Gson gson = new Gson();
        String json = MainActivity.tinyDB.getString("VocLists");
        if(json != null){
            Type type = new TypeToken<ArrayList<VocabularyList>>() {}.getType();
            VocabularyMethods.vocabularylists = gson.fromJson(json, type);
        }else{
            VocabularyMethods.vocabularylists = new ArrayList<VocabularyList>();
        }


        //Initialisieren der Knöpfe und rufen der OnClick methode

        base = (Button) findViewById(R.id.vocabulary_base);
        nolist = (TextView) findViewById(R.id.vocabulary_nolists);
        lang1 = (TextView) findViewById(R.id.vocabulary_language);
        lang2 = (TextView) findViewById(R.id.vocabulary_language1);
        original = (TextView) findViewById(R.id.vocabulary_original);
        translation = (TextView) findViewById(R.id.vocabulary_translation);

        all = (Button) findViewById(R.id.vocabulary_all);
        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                open_all();
            }
        });

        back1 = (Button) findViewById(R.id.vocabulary_back1);
        back1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_back1();
            }
        });

        train = (Button) findViewById(R.id.vocabulary_train);

        back = (Button) findViewById(R.id.vocabulary_back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_back();
            }
        });

        create = (Button) findViewById(R.id.vocabulary_create);
        create.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_create();
            }
        });

        error = (TextView) findViewById(R.id.vocabulary_error);

        ShowLists();

        for (int i = 0; i < buttonlanglist.size(); i++){
            Button b = buttonlanglist.get(i);
            b.setVisibility(View.GONE);
        }
    }

    @Override
    public void onPause() {
        super.onPause();

        Gson gson = new Gson();
        String json = gson.toJson(VocabularyMethods.vocabularylists);
        MainActivity.tinyDB.putString("VocLists", json);
    }

    @Override
    public void onStop() {
        super.onStop();

        Gson gson = new Gson();
        String json = gson.toJson(VocabularyMethods.vocabularylists);
        MainActivity.tinyDB.putString("VocLists", json);

    }

    public void ShowLists(){
        int d = 0;
        int e = 0;
        boolean f = true;

        if(VocabularyMethods.vocabularylists != null) {
            nolist.setVisibility(View.GONE);
            all.setEnabled(true);
            base.setVisibility(View.INVISIBLE);
            Button down[] = new Button[VocabularyMethods.vocabularylists.size()];

            for (int i = 0; i < VocabularyMethods.vocabularylists.size(); i++) {
                if (!(VocabularyMethods.vocabularylists.get(i).getName().contains("AllVoc_"))) {
                        if (!(base.getVisibility() == View.INVISIBLE)) {
                            down[i] = new Button(Vokabeln.this);

                            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                            params.setMargins(8, 90, 8, 8);

                            down[i].setText(VocabularyMethods.vocabularylists.get(i).getName());
                            down[i].setId(i);


                            Log.d("i = " + i, "added button with name " + VocabularyMethods.vocabularylists.get(i).getName() + " to view");
                            layout.addView(down[i], params);


                            constraintSet = new ConstraintSet();
                            constraintSet.clone(layout);
                            if (f == true) {
                                constraintSet.connect(i, ConstraintSet.TOP, base.getId(), ConstraintSet.BOTTOM);

                                constraintSet.connect(i, ConstraintSet.RIGHT, base.getId(), ConstraintSet.RIGHT);
                                constraintSet.connect(i, ConstraintSet.LEFT, base.getId(), ConstraintSet.LEFT);
                                f = false;
                            } else {
                                constraintSet.connect(i, ConstraintSet.TOP, e - 1, ConstraintSet.BOTTOM);

                                constraintSet.connect(i, ConstraintSet.RIGHT, e - 1, ConstraintSet.RIGHT);
                                constraintSet.connect(i, ConstraintSet.LEFT, e - 1, ConstraintSet.LEFT);
                            }

                            e = i + 1;
                            constraintSet.applyTo(layout);
                            showvocabularys(down[i], i);
                            buttonlist.add(down[i]);
                        } else {
                            base.setVisibility(View.VISIBLE);
                            base.setText(VocabularyMethods.vocabularylists.get(i).getName());
                            showvocabularys(base, i);
                            buttonlist.add(base);
                        }
                        d++;
                }else{
                        if (!(base.getVisibility() == View.INVISIBLE)) {
                            down[i] = new Button(Vokabeln.this);

                            ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                            params.setMargins(8, 90, 8, 8);

                            down[i].setText(VocabularyMethods.vocabularylists.get(i).getLanguageName1() + " - " + VocabularyMethods.vocabularylists.get(i).getLanguageName2());
                            down[i].setId(i);


                            Log.d("i = " + i, "added button with name " + VocabularyMethods.vocabularylists.get(i).getName() + " to view");
                            layout.addView(down[i], params);


                            constraintSet = new ConstraintSet();
                            constraintSet.clone(layout);
                            if (f == true) {
                                constraintSet.connect(i, ConstraintSet.TOP, base.getId(), ConstraintSet.BOTTOM);

                                constraintSet.connect(i, ConstraintSet.RIGHT, base.getId(), ConstraintSet.RIGHT);
                                constraintSet.connect(i, ConstraintSet.LEFT, base.getId(), ConstraintSet.LEFT);
                                f = false;
                            } else {
                                constraintSet.connect(i, ConstraintSet.TOP, e - 1, ConstraintSet.BOTTOM);

                                constraintSet.connect(i, ConstraintSet.RIGHT, e - 1, ConstraintSet.RIGHT);
                                constraintSet.connect(i, ConstraintSet.LEFT, e - 1, ConstraintSet.LEFT);
                            }

                            e = i + 1;
                            constraintSet.applyTo(layout);
                            showvocabularys(down[i], i);
                            buttonlanglist.add(down[i]);
                        } else {
                            base.setVisibility(View.VISIBLE);
                            base.setText(VocabularyMethods.vocabularylists.get(i).getLanguageName1() + " - " + VocabularyMethods.vocabularylists.get(i).getLanguageName2());
                            showvocabularys(base, i);
                            buttonlanglist.add(base);
                        }
                        d++;
                }
            }
        }else{
            nolist.setVisibility(View.VISIBLE);
            base.setVisibility(View.INVISIBLE);
            all.setEnabled(false);
        }
    }

    //Buttton OnClick Methoden

    public void showvocabularys(Button b, final int id){

        train.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                start_train(id);
            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                train.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        start_train(id);
                    }
                });

                vocabularylist =  VocabularyMethods.vocabularylists.get(id).getVocabularylist();
                downoriginal  = new TextView[vocabularylist.size()];
                downtranslation = new TextView[vocabularylist.size() + 10000];

                if(vocabularylist.size() < 5){
                    error.setVisibility(View.VISIBLE);
                    error.setText("Es müssen mindestens 5 Vokabeln in der Vokabelliste vorhanden sein, um die Übung zu starten");
                    train.setEnabled(false);
                }else{
                    error.setVisibility(View.GONE);
                    error.setText("");
                    train.setEnabled(true);
                }

                boolean f = true;
                int e = 0;

                boolean f1 = true;
                int e1 = 0;

                findViewById(R.id.vocabulary_scrollView).setVisibility(View.INVISIBLE);
                findViewById(R.id.vocabulary_scrollview1).setVisibility(View.VISIBLE);

                lang1.setText(VocabularyMethods.vocabularylists.get(id).getLanguageName1());
                lang2.setText(VocabularyMethods.vocabularylists.get(id).getLanguageName2());

                for (int i = 1; i < vocabularylist.size(); i++) {
                    downoriginal[i] = new TextView(Vokabeln.this);

                    ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                    params.setMargins(8, 90, 8, 8);

                    downoriginal[i].setText(vocabularylist.get(i).getOriginal());
                    downoriginal[i].setId(i);

                    layout1.addView(downoriginal[i], params);
                    constraintSeto = new ConstraintSet();
                    constraintSeto.clone(layout1);

                    if(f == true){
                        constraintSeto.connect(i, ConstraintSet.TOP, original.getId(), ConstraintSet.BOTTOM);
                        constraintSeto.connect(i , ConstraintSet.RIGHT, original.getId(), ConstraintSet.RIGHT);
                        constraintSeto.connect(i, ConstraintSet.LEFT, original.getId(), ConstraintSet.LEFT);
                        f = false;
                    }else{
                        constraintSeto.connect(i, ConstraintSet.TOP, e - 1, ConstraintSet.BOTTOM);
                        constraintSeto.connect(i, ConstraintSet.RIGHT, e - 1, ConstraintSet.RIGHT);
                        constraintSeto.connect(i, ConstraintSet.LEFT, e - 1, ConstraintSet.LEFT);
                    }

                    e = i + 1;
                    constraintSeto.applyTo(layout1);
                }
                original.setText(vocabularylist.get(0).getOriginal());



                for (int i = 1; i < vocabularylist.size(); i++) {
                    downtranslation[i + 10000] = new TextView(Vokabeln.this);

                    ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);

                    params.setMargins(8, 90, 8, 8);

                    downtranslation[i + 10000].setText(vocabularylist.get(i).getTranslation());
                    downtranslation[i + 10000].setId(i + 10000);

                    layout1.addView(downtranslation[i + 10000], params);
                    constraintSett = new ConstraintSet();
                    constraintSett.clone(layout1);

                    if(f1 == true){
                        constraintSett.connect(i + 10000, ConstraintSet.TOP, translation.getId(), ConstraintSet.BOTTOM);
                        constraintSett.connect(i  + 10000, ConstraintSet.RIGHT, translation.getId(), ConstraintSet.RIGHT);
                        constraintSett.connect(i + 10000, ConstraintSet.LEFT, translation.getId(), ConstraintSet.LEFT);
                        f1 = false;
                    }else{
                        constraintSett.connect(i + 10000, ConstraintSet.TOP, e1 - 1 + 10000, ConstraintSet.BOTTOM);
                        constraintSett.connect(i + 10000, ConstraintSet.RIGHT, e1 - 1 + 10000, ConstraintSet.RIGHT);
                        constraintSett.connect(i + 10000, ConstraintSet.LEFT, e1 - 1 + 10000, ConstraintSet.LEFT);
                    }

                    e1 = i + 1;
                    constraintSett.applyTo(layout1);
                }
                translation.setText(vocabularylist.get(0).getTranslation());

            }
        });
    }

    public void open_back(){
        Intent intent = new Intent(this, Learn.class);
        startActivity(intent);
    }

    public void open_back1(){
        for(int i = 0; i < downoriginal.length; i++){
            layout1.removeView(downoriginal[i]);
        }

        for(int i = 0; i < downtranslation.length; i++){
            layout1.removeView(downtranslation[i]);
        }
        findViewById(R.id.vocabulary_scrollView).setVisibility(View.VISIBLE);
        findViewById(R.id.vocabulary_scrollview1).setVisibility(View.INVISIBLE);
    }

    public void open_create(){
        Intent intent = new Intent(this, CreateVocList.class);
        startActivity(intent);
    }


    //Lernbereich

    Vocabulary voc;
    int lastvocabulary;


    public void open_learn_back(){
        learn_translation.setText(null);
        findViewById(R.id.vocabulary_scrollView5).setVisibility(View.INVISIBLE);
        findViewById(R.id.vocabulary_scrollview1).setVisibility(View.VISIBLE);
    }


    public void start_train(final int id) {

        Log.d("start_train", "id: " + id);

        final ArrayList<Vocabulary> level0 = new ArrayList<Vocabulary>();
        final ArrayList<Vocabulary> level1 = new ArrayList<Vocabulary>();
        final ArrayList<Vocabulary> level2 = new ArrayList<Vocabulary>();
        final ArrayList<Vocabulary> level3 = new ArrayList<Vocabulary>();
        final ArrayList<Vocabulary> level4 = new ArrayList<Vocabulary>();

        vocabularylist = VocabularyMethods.vocabularylists.get(id).getVocabularylist();

        findViewById(R.id.vocabulary_scrollView5).setVisibility(View.VISIBLE);
        findViewById(R.id.vocabulary_scrollview1).setVisibility(View.INVISIBLE);

        learn_input.setVisibility(View.VISIBLE);
        learn_translation.setVisibility(View.VISIBLE);
        learn_showtranslation.setVisibility(View.VISIBLE);
        learn_enter.setVisibility(View.VISIBLE);
        learn_masterTranslation.setVisibility(View.INVISIBLE);
        learn_right.setVisibility(View.INVISIBLE);
        learn_wrong.setVisibility(View.INVISIBLE);

        learn_level0Score.setText("" + vocabularylist.size());


        for (int i = 0; i < vocabularylist.size(); i++) {
            level0.add(vocabularylist.get(i));
        }

        open_train(id, level0, level1, level2, level3, level4);

    }

    public void open_train(final int id, final ArrayList<Vocabulary> level0, final ArrayList<Vocabulary> level1, final ArrayList<Vocabulary> level2, final ArrayList<Vocabulary> level3, final ArrayList<Vocabulary> level4){
        String s = learn_translation.getText().toString();
        learn_level0Score.setText(level0.size() + "");
        learn_level1Score.setText(level1.size() + "");
        learn_level2Score.setText(level2.size() + "");
        learn_level3Score.setText(level3.size() + "");
        learn_level4Score.setText(level4.size() + "");


        while(true){
            int d = new Random().nextInt(vocabularylist.size());

            Log.d("last", "Last: " + lastvocabulary);

            if(!(level4.contains(vocabularylist.get(d)))){

                if(d != lastvocabulary){

                    voc = vocabularylist.get(d);
                    lastvocabulary = d;
                    break;

                }else{

                    if((level0.size() == 1) && (level1.size() == 0) && (level2.size() == 0) && (level3.size() == 0)){
                        voc = level0.get(0);
                        lastvocabulary = d;
                        break;
                    }else if((level0.size() == 0) && (level1.size() == 1) && (level2.size() == 0) && (level3.size() == 0)){
                        voc = level1.get(0);
                        lastvocabulary = d;
                        break;
                    }else if((level0.size() == 0) && (level1.size() == 0) && (level2.size() == 1) && (level3.size() == 0)){
                        voc = level2.get(0);
                        lastvocabulary = d;
                        break;
                    }else if((level0.size() == 0) && (level1.size() == 0) && (level2.size() == 0) && (level3.size() == 1)) {
                        voc = level3.get(0);
                        lastvocabulary = d;
                        break;
                    }
                }
            }

        }

        if (vocabularylist.indexOf(voc) % 2 == 0){

            learn_language.setText(voc.getLanguageName1());
            learn_original.setText(voc.getOriginal());
            learn_language1.setText(voc.getLanguageName2());

            learn_showtranslation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    learn_input.setVisibility(View.INVISIBLE);
                    learn_translation.setVisibility(View.INVISIBLE);
                    learn_showtranslation.setVisibility(View.INVISIBLE);
                    learn_enter.setVisibility(View.INVISIBLE);
                    learn_masterTranslation.setVisibility(View.VISIBLE);
                    learn_right.setVisibility(View.VISIBLE);
                    learn_wrong.setVisibility(View.VISIBLE);
                    if(level0.contains(voc)) {
                        open_learn_showtranslation(true, level0, level1, level2, level3, level4, id);
                    }else if(level1.contains(voc)) {
                        open_learn_showtranslation(false, level0, level1, level2, level3, level4, id);
                    }else if(level2.contains(voc)) {
                        open_learn_showtranslation(true, level0, level1, level2, level3, level4, id);
                    }else if(level3.contains(voc)) {
                        open_learn_showtranslation(false, level0, level1, level2, level3, level4, id);
                    }
                }
            });


            learn_enter.setOnClickListener(new View.OnClickListener(){
                public void onClick(View view){

                    if (level0.contains(voc)) {
                        open_learn_enter(true, level0, level1, level2, level3, level4, id);
                    } else if (level1.contains(voc)) {
                        open_learn_enter(false, level0, level1, level2, level3, level4, id);
                    } else if (level2.contains(voc)) {
                        open_learn_enter(true, level0, level1, level2, level3, level4, id);
                    } else if (level3.contains(voc)) {
                        open_learn_enter(false, level0, level1, level2, level3, level4, id);
                    }
                }
            });

        } else {

            learn_language.setText(voc.getLanguageName2());
            learn_original.setText(voc.getTranslation());
            learn_language1.setText(voc.getLanguageName1());

            learn_showtranslation.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    learn_input.setVisibility(View.INVISIBLE);
                    learn_translation.setVisibility(View.INVISIBLE);
                    learn_showtranslation.setVisibility(View.INVISIBLE);
                    learn_enter.setVisibility(View.INVISIBLE);
                    learn_masterTranslation.setVisibility(View.VISIBLE);
                    learn_right.setVisibility(View.VISIBLE);
                    learn_wrong.setVisibility(View.VISIBLE);

                    if(level0.contains(voc)) {
                        open_learn_showtranslation(false, level0, level1, level2, level3, level4, id);
                    }else if(level1.contains(voc)) {
                        open_learn_showtranslation(true, level0, level1, level2, level3, level4, id);
                    }else if(level2.contains(voc)) {
                        open_learn_showtranslation(false, level0, level1, level2, level3, level4, id);
                    }else if(level3.contains(voc)) {
                        open_learn_showtranslation(true, level0, level1, level2, level3, level4, id);
                    }
                }
            });


            learn_enter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if(level0.contains(voc)) {
                        open_learn_enter(false, level0, level1, level2, level3, level4, id);
                    }else if(level1.contains(voc)) {
                        open_learn_enter(true, level0, level1, level2, level3, level4, id);
                    }else if(level2.contains(voc)) {
                        open_learn_enter(false, level0, level1, level2, level3, level4, id);
                    }else if(level3.contains(voc)) {
                        open_learn_enter(true, level0, level1, level2, level3, level4, id);
                    }
                }

            });
        }
    }

    public void open_learn_enter(boolean gerade, ArrayList<Vocabulary> level0, ArrayList<Vocabulary> level1, ArrayList<Vocabulary> level2, ArrayList<Vocabulary> level3, ArrayList<Vocabulary> level4, int id){

        MainActivity.hideKeyboard(this);
        vocabularylist =  VocabularyMethods.vocabularylists.get(id).getVocabularylist();

        if(gerade == false) {
            learn_languages.setText(voc.getLanguageName1() + " - " + voc.getLanguageName2());
            learn_vocabularys.setText(voc.getOriginal() + " - " + voc.getTranslation());


            if(!(learn_translation.getText().toString().equalsIgnoreCase(voc.getOriginal()))) {

                if(level4.size() == vocabularylist.size()){
                    openfinish();
                }else {

                    if(level1.contains(voc)){
                        level0.add(voc);
                        level1.remove(voc);
                    }else if(level2.contains(voc)){
                        level1.add(voc);
                        level2.remove(voc);
                    }else if(level3.contains(voc)) {
                        level2.add(voc);
                        level3.remove(voc);
                    }

                    Log.d("Wrong", "Next Vocabulary, Ungerade");
                    Log.d("Wrong", voc.getTranslation() + " != " + learn_translation.getText().toString());
                    open_train(id, level0, level1, level2, level3, level4);
                }
            }else{

                if(level0.contains(voc)){
                    level0.remove(voc);
                    level1.add(voc);
                }else if(level1.contains(voc)){
                    level1.remove(voc);
                    level2.add(voc);
                }else if(level2.contains(voc)){
                    level2.remove(voc);
                    level3.add(voc);
                }else if(level3.contains(voc)) {
                    level3.remove(voc);
                    level4.add(voc);
                }


                if(level4.size() == vocabularylist.size()){
                    Log.d("Right", "Finish");
                    openfinish();
                }else {
                    Log.d("Right", "Next Vocabulary, ID: Ungerade");
                    Log.d("Right", voc.getTranslation() + " == " + learn_translation.getText().toString());
                    open_train(id, level0, level1, level2, level3, level4);
                }
            }

        }else {


            learn_languages.setText(voc.getLanguageName2() + " - " + voc.getLanguageName1());
            learn_vocabularys.setText(voc.getTranslation() + " - " + voc.getOriginal());


            if(!(learn_translation.getText().toString().equalsIgnoreCase(voc.getTranslation()))) {

                if(level4.size() == vocabularylist.size()){
                    openfinish();
                }else {

                    if(level1.contains(voc)){
                        level0.add(voc);
                        level1.remove(voc);
                    }else if(level2.contains(voc)){
                        level1.add(voc);
                        level2.remove(voc);
                    }else if(level3.contains(voc)) {
                        level2.add(voc);
                        level3.remove(voc);
                    }

                    Log.d("Wrong", "Next Vocabulary, ID: Gerade");
                    Log.d("Wrong", voc.getOriginal() + " != " + learn_translation.getText().toString());
                    open_train(id, level0, level1, level2, level3, level4);
                }
            }else{

                if(level0.contains(voc)){
                    level0.remove(voc);
                    level1.add(voc);
                }else if(level1.contains(voc)){
                    level1.remove(voc);
                    level2.add(voc);
                }else if(level2.contains(voc)){
                    level2.remove(voc);
                    level3.add(voc);
                }else if(level3.contains(voc)) {
                    level3.remove(voc);
                    level4.add(voc);
                }

                if(level4.size() == vocabularylist.size()){
                    Log.d("Right", "Finish");
                    openfinish();
                }else {
                    Log.d("Right", "Next Vocabulary, Gerade");
                    Log.d("Right", voc.getOriginal() + " == " + learn_translation.getText().toString());
                    open_train(id, level0, level1, level2, level3, level4);
                }
            }

        }

        learn_translation.setText(null);

    }


    public void openfinish(){
        learn_level0Score.setText("0");
        learn_level1Score.setText("0");
        learn_level2Score.setText("0");
        learn_level3Score.setText("0");
        learn_level4Score.setText("0");
        learn_translation.setText(null);
        findViewById(R.id.vocabulary_scrollView5).setVisibility(View.INVISIBLE);
        findViewById(R.id.vocabulary_scrollview1).setVisibility(View.VISIBLE);
    }









    public void open_learn_showtranslation(final boolean gerade, final ArrayList<Vocabulary> level0, final ArrayList<Vocabulary> level1, final ArrayList<Vocabulary> level2, final ArrayList<Vocabulary> level3, final ArrayList<Vocabulary> level4, final int id){

        MainActivity.hideKeyboard(this);
        vocabularylist =  VocabularyMethods.vocabularylists.get(id).getVocabularylist();


        learn_right.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                learn_input.setVisibility(View.VISIBLE);
                learn_translation.setVisibility(View.VISIBLE);
                learn_showtranslation.setVisibility(View.VISIBLE);
                learn_enter.setVisibility(View.VISIBLE);
                learn_masterTranslation.setVisibility(View.INVISIBLE);
                learn_right.setVisibility(View.INVISIBLE);
                learn_wrong.setVisibility(View.INVISIBLE);

                if(gerade == false) {

                    learn_masterTranslation.setText(voc.getTranslation());

                    learn_languages.setText(voc.getLanguageName1() + " - " + voc.getLanguageName2());
                    learn_vocabularys.setText(voc.getOriginal() + " - " + voc.getTranslation());

                    if(level4.size() == vocabularylist.size()){
                        openfinish();
                    }else {

                        if(level1.contains(voc)){
                            level0.add(voc);
                            level1.remove(voc);
                        }else if(level2.contains(voc)){
                            level1.add(voc);
                            level2.remove(voc);
                        }else if(level3.contains(voc)) {
                            level2.add(voc);
                            level3.remove(voc);
                        }

                        Log.d("Right", "Next Vocabulary, Ungerade");
                        Log.d("Right", voc.getTranslation() + " != " + learn_translation.getText().toString());
                        open_train(id, level0, level1, level2, level3, level4);
                    }

                }else{

                    learn_masterTranslation.setText(voc.getOriginal());

                    learn_languages.setText(voc.getLanguageName2() + " - " + voc.getLanguageName1());
                    learn_vocabularys.setText(voc.getTranslation() + " - " + voc.getOriginal());

                    if(level4.size() == vocabularylist.size()){
                        openfinish();
                    }else {

                        if(level1.contains(voc)){
                            level0.add(voc);
                            level1.remove(voc);
                        }else if(level2.contains(voc)){
                            level1.add(voc);
                            level2.remove(voc);
                        }else if(level3.contains(voc)) {
                            level2.add(voc);
                            level3.remove(voc);
                        }

                        Log.d("Right", "Next Vocabulary, ID: Gerade");
                        Log.d("Right", voc.getOriginal() + " != " + learn_translation.getText().toString());
                        open_train(id, level0, level1, level2, level3, level4);
                    }

                }

            }


        });


        learn_wrong.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                learn_input.setVisibility(View.VISIBLE);
                learn_translation.setVisibility(View.VISIBLE);
                learn_showtranslation.setVisibility(View.VISIBLE);
                learn_enter.setVisibility(View.VISIBLE);
                learn_masterTranslation.setVisibility(View.INVISIBLE);
                learn_right.setVisibility(View.INVISIBLE);
                learn_wrong.setVisibility(View.INVISIBLE);

                    if(gerade == false) {

                        learn_masterTranslation.setText(voc.getTranslation());
                        learn_languages.setText(voc.getLanguageName1() + " - " + voc.getLanguageName2());
                        learn_vocabularys.setText(voc.getOriginal() + " - " + voc.getTranslation());

                        if(level0.contains(voc)){
                            level0.remove(voc);
                            level1.add(voc);
                        }else if(level1.contains(voc)){
                            level1.remove(voc);
                            level2.add(voc);
                        }else if(level2.contains(voc)){
                            level2.remove(voc);
                            level3.add(voc);
                        }else if(level3.contains(voc)) {
                            level3.remove(voc);
                            level4.add(voc);
                        }


                        if(level4.size() == vocabularylist.size()){
                            Log.d("Wrong", "Finish");
                            openfinish();
                        }else {
                            Log.d("Wrong", "Next Vocabulary, ID: Ungerade");
                            Log.d("Wrong", voc.getTranslation() + " == " + learn_translation.getText().toString());
                            open_train(id, level0, level1, level2, level3, level4);
                        }

                    }else{

                        learn_masterTranslation.setText(voc.getOriginal());
                        learn_languages.setText(voc.getLanguageName2() + " - " + voc.getLanguageName1());
                        learn_vocabularys.setText(voc.getTranslation() + " - " + voc.getOriginal());

                        if(level0.contains(voc)){
                            level0.remove(voc);
                            level1.add(voc);
                        }else if(level1.contains(voc)){
                            level1.remove(voc);
                            level2.add(voc);
                        }else if(level2.contains(voc)){
                            level2.remove(voc);
                            level3.add(voc);
                        }else if(level3.contains(voc)) {
                            level3.remove(voc);
                            level4.add(voc);
                        }

                        if(level4.size() == vocabularylist.size()){
                            Log.d("Wrong", "Finish");
                            openfinish();
                        }else {
                            Log.d("Wrong", "Next Vocabulary, Gerade");
                            Log.d("Wrong", voc.getOriginal() + " == " + learn_translation.getText().toString());
                            open_train(id, level0, level1, level2, level3, level4);
                        }

                    }

                }

        });

        learn_translation.setText(null);


    }



    //Lernbereich


    public void open_all(){

        boolean created = false;

        all.setVisibility(View.INVISIBLE);
        base.setVisibility(View.INVISIBLE);
        create.setVisibility(View.INVISIBLE);

        for (int i = 0; i < buttonlist.size(); i++){
            Button b = buttonlist.get(i);
        }

        for (int i = 0; i < buttonlist.size(); i++){
            Button b = buttonlist.get(i);
            b.setVisibility(View.GONE);
        }
        for (int i = 0; i < buttonlanglist.size(); i++){
            Button b = buttonlanglist.get(i);
            b.setVisibility(View.VISIBLE);
        }



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < buttonlist.size(); i++){
                    Button b = buttonlist.get(i);
                    b.setVisibility(View.VISIBLE);
                }
                for (int i = 0; i < buttonlanglist.size(); i++){
                    Button b = buttonlanglist.get(i);
                    b.setVisibility(View.GONE);
                }


                all.setVisibility(View.VISIBLE);
                create.setVisibility(View.VISIBLE);

                back.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        open_back();
                    }
                });
            }
        });

    }



























}