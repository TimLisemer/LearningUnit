package learningunit.learningunit.Menu;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;

import learningunit.learningunit.BeforeStart.FirstScreen;
import learningunit.learningunit.Menu.Learn.Learn;
import learningunit.learningunit.Menu.Organizer.Organizer;
import learningunit.learningunit.Objects.API.TinyDB;
import learningunit.learningunit.R;

public class MainActivity extends AppCompatActivity {

    //Deklarieren der Knöpfe
    private Button logout, play, learn, organizer, timetable, statistics, settings;
    public static SharedPreferences sharedPreferences;
    public static TinyDB tinyDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences = getSharedPreferences("variables", MODE_PRIVATE);
        tinyDB = new TinyDB(this);

        //Initialisieren der Knöpfe und rufen der OnClick methode
        logout = (Button) findViewById(R.id.main_logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_logout();
            }
        });

        play = (Button) findViewById(R.id.main_play);
        play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_play();
            }
        });

        learn = (Button) findViewById(R.id.main_learn);
        learn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_learn();
            }
        });

        organizer = (Button) findViewById(R.id.main_organizer);
        organizer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_organizer();
            }
        });

        timetable = (Button) findViewById(R.id.main_timetable);
        timetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_timetable();
            }
        });

        statistics = (Button) findViewById(R.id.main_statistics);
        statistics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_statistics();
            }
        });

        settings = (Button) findViewById(R.id.main_settings);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                open_settings();
            }
        });

    }




    //Buttton OnClick Methoden
    public void open_logout(){
        Intent intent = new Intent(this, FirstScreen.class);
        startActivity(intent);
    }

    public void open_play(){
        //Intent intent = new Intent(this, FirstScreen.class);
        //startActivity(intent);
    }

    public void open_learn(){
        Intent intent = new Intent(this, Learn.class);
        startActivity(intent);
    }

    public void open_organizer(){
        Intent intent = new Intent(this, Organizer.class);
        startActivity(intent);
    }

    public void open_timetable(){
        //Intent intent = new Intent(this, FirstScreen.class);
        //startActivity(intent);
    }

    public void open_statistics(){
        //Intent intent = new Intent(this, FirstScreen.class);
        //startActivity(intent);
    }

    public void open_settings(){
        //Intent intent = new Intent(this, FirstScreen.class);
        //startActivity(intent);
    }

    public static void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public static void showKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.showSoftInput(view, 0);
    }



}
